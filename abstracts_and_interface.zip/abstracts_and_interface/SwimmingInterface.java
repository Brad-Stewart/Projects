package com.edwardim.advancedoop;

public interface SwimmingInterface {
	
	double neutralBobbingLevel = 10;
	
	void swimming();
	void drowning();

}
