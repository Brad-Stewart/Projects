package com.edwardim.advancedoop;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Human cabbage_guy = new Human();
		
		
		FireHuman zuko = new FireHuman("Zuko", 16, 66, 80);
		
	}

}
