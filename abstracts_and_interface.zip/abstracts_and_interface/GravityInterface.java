package com.edwardim.advancedoop;

public interface GravityInterface {
	// FINAL AND STATIC
	double gravity = 9.8;
	
	// NEEDS TO BE IMPLEMENTED BY THE CLASS THAT IMPLEMENTS THESE INTERACES	
	void fallDown();
	
}
