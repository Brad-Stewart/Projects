from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Job
import bcrypt

# Create your views here.
def index(request):
    return render(request, "index.html")

def register(request):
    errors = User.objects.validate_register(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")

    else:
        hash_pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()

        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = hash_pw
        )
        request.session['user_id'] = new_user.id
        return redirect("/dashboard")
    
def login(request):
    user_list = User.objects.filter(email = request.POST['email'])

    if len(user_list) == 0:
        messages.error(request, "Invalid Credentials")
        return redirect("/")

    logged_user = user_list[0]
    if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
        request.session['user_id'] = logged_user.id
        return redirect("/dashboard")
    else:
        messages.error(request, "Invalid Credentials")
        return redirect("/")

def newJob(request):
    return render(request, "new.html")


def processJob(request):
    context = {
        "current_user" : User.objects.get(id = request.session['user_id'])
    }
    errors = Job.objects.validate_job(request.POST)
    print(errors)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/jobs/new")

    print("Creating a new job")
    logged_user = User.objects.get(id = request.session['user_id'])

    new_job = Job.objects.create(
        title = request.POST['title'],
        description = request.POST['description'],
        location = request.POST['location'],
        creator = logged_user
    )
    return redirect("/dashboard")


def dashboard(request):
    context = {
        "all_jobs" : Job.objects.all(),
        "current_user" : User.objects.get(id = request.session['user_id'])
    }
    return render(request, "dashboard.html", context)

def editJob(request, job_id):
    print(job_id)
    context = {
        "edit_job" : Job.objects.get(id = job_id),
        "current_user" : User.objects.get(id = request.session['user_id'])
    }
    return render(request, "edit.html", context)

def updateJob(request, job_id):
    errors = Job.objects.validate_job(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/jobs/{job_id}/edit")
    edit_job = Job.objects.get(id = job_id)

    edit_job.title = request.POST['title']
    edit_job.description = request.POST['description']
    edit_job.location = request.POST['location']

    edit_job.save()
    return redirect("/dashboard")

def delete(request, job_id):
    job = Job.objects.get(id = job_id)
    job.delete()
    return redirect("/dashboard")

def view(request, job_id):
    context = {
        "current_job" : Job.objects.get(id = job_id),
        "current_user" : User.objects.get(id = request.session['user_id'])
    }
    return render(request, "view.html", context)