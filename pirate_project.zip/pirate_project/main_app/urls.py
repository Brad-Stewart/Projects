from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("register", views.register),
    path("login", views.login),
    path("jobs/new", views.newJob),
    path("jobs/process", views.processJob),
    path("jobs/<int:job_id>/update", views.updateJob),
    path("jobs/<int:job_id>/edit", views.editJob),
    path("dashboard", views.dashboard),
    path("jobs/<int:job_id>/delete", views.delete),
    path("jobs/<int:job_id>/view", views.view)
]