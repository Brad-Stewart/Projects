from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Trip
import bcrypt

# Create your views here.
def index(request):
    return render(request, "index.html")

def register(request):
    errors = User.objects.validate_register(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")

    else:
        hash_pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()

        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = hash_pw
        )
        request.session['user_id'] = new_user.id
        return redirect("/dashboard")
    
def login(request):
    user_list = User.objects.filter(email = request.POST['email'])

    if len(user_list) == 0:
        messages.error(request, "Invalid Credentials")
        return redirect("/")

    logged_user = user_list[0]
    if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
        request.session['user_id'] = logged_user.id
        return redirect("/dashboard")
    else:
        messages.error(request, "Invalid Credentials")
        return redirect("/")

def newTrip(request):
    return render(request, "new.html")


def processTrip(request):
    errors = Trip.objects.validate_trip(request.POST)
    print(errors)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/trips/new")

    print("Creating a new trip")
    logged_user = User.objects.get(id = request.session['user_id'])

    new_trip = Trip.objects.create(
        destination = request.POST['destination'],
        start_date = request.POST['start_date'],
        end_date = request.POST['end_date'],
        plan = request.POST['plan'],
        creator = logged_user
    )
    return redirect("/dashboard")


def dashboard(request):
    context = {
        "all_trips" : Trip.objects.all(),
        "current_user" : User.objects.get(id = request.session['user_id'])
    }
    return render(request, "dashboard.html", context)

def editTrip(request, trip_id):
    print(trip_id)
    context = {
        "edit_trip" : Trip.objects.get(id = trip_id)
    }
    return render(request, "edit.html", context)

def updateTrip(request, trip_id):
    errors = Trip.objects.validate_trip(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/trips/{trip_id}/edit")
    edit_trip = Trip.objects.get(id = trip_id)

    edit_trip.destination = request.POST['destination']
    edit_trip.start_date = request.POST['start_date']
    edit_trip.end_date = request.POST['end_date']
    edit_trip.plan = request.POST['plan']

    edit_trip.save()
    return redirect("/dashboard")

def delete(request, trip_id):
    trip = Trip.objects.get(id = trip_id)
    trip.delete()
    return redirect("/dashboard")

def view(request, trip_id):
    context = {
        "current_trip" : Trip.objects.get(id = trip_id),
        "current_user" : User.objects.get(id = request.session['user_id'])
    }
    return render(request, "view.html", context)