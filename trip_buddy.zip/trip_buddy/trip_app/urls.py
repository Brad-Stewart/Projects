from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("register", views.register),
    path("login", views.login),
    path("trips/new", views.newTrip),
    path("trips/process", views.processTrip),
    path("trips/<int:trip_id>/update", views.updateTrip),
    path("trips/<int:trip_id>/edit", views.editTrip),
    path("dashboard", views.dashboard),
    path("trips/<int:trip_id>/delete", views.delete),
    path("trips/<int:trip_id>/view", views.view)
]