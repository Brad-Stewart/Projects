from django.db import models
import re
# Create your models here.
class UserManager(models.Manager):
    def validate_register(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First name must be longer than 2 characters"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last name must be longer than 2 characters"
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-z]')
        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = "Invalid email address!"
        
        user_list = User.objects.filter(email = postData['email'])
        if len(user_list) > 0:
            errors['email_duplicate'] = "Email already exists in database"
        
        if len(postData['password']) < 9: 
            errors['password'] = "Password must be at least 8 characters"

        if postData['password'] != postData['confirm_password']:
            errors['match_password'] = "Your Password and Confirm Password must match"
        return errors

class User(models.Model):
    first_name = models.CharField(max_length = 45)
    last_name = models.CharField(max_length = 45)
    email = models.CharField(max_length = 45)
    password = models.CharField(max_length = 255)

    objects = UserManager()

    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)


class TripManager(models.Manager):
    def validate_trip(self, postData):
        errors = {}
        if len(postData['destination']) < 3:
            errors['destination'] = "Destination must be at least 4 characters"
        if len(postData['start_date']) == 0:
            errors['start_date'] = "Start date must be provided"
        if len(postData['end_date']) == 0:
            errors['end_date'] = "End date must be provided"
        if len(postData['plan']) < 3:
            errors['plan'] = "Plan must be at least 4 characters"
        return errors


class Trip(models.Model):
    destination = models.CharField(max_length = 255)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    plan = models.TextField()

    objects = TripManager()
    creator = models.ForeignKey(User, related_name = "trips", on_delete = models.CASCADE)

    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)