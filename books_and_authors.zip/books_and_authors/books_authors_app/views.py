from django.shortcuts import render, HttpResponse, redirect
from .models import Book, Author

def index(request):
    context = {
        "Books" : Book.objects.all(),
    }
    return render(request, "books_authors_app/index.html", context)

def books(request, id):
    context = {
        "Books" : Book.objects.get(id = id),
        "Authors" : Book.objects.get(id = id).authors(),
        "All_Authors" : Author.objects.all(),
    }
    return render(requesst, "books_authors_app/books.html", context)

def newBook(request):
    if request.method == "POST":
        title = request.POST["book_title"]
        description = request.POST["book_description"]
        add_book = Book.objects.create(title = title, summary = summary)

        return redirect('/books/' + str(bew_book.id))

def newAuthor(request):
    if request.method == "POST":
        id = request.POST["book_id"]
        book = Book.objects.get(id = id)
        author_id = request.POST["authors"]
        author = Author.objects.get(id = author_id)
        book.authors.add(authors)
        return redirect('/books' + id)

def authorHome(request):
    context = {
        "Authors": Author.objects.all(),
    }

    return render(request, "books_authors_app/authors.html", context)

def newBookAuthor(request):
    if request.method == "POST":
        id = request.POST["authors"]
        author = Author.objects.get(id=id)
        book_id = request.POST["bookid"]
        books = Book.objects.get(id=book_id)
        author.books.add(books)

        return redirect('/author/' + id)

def addNewAuthor(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        notes = request.POST["notes"]
        new_author = Author.objects.create(first_name=first_name, last_name=last_name, notes=notes)

        return redirect('/author/' + str(new_author.id))