from django.apps import AppConfig


class SemiRestAppConfig(AppConfig):
    name = 'semi_rest_app'
