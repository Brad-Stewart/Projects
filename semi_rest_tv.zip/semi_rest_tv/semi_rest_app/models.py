from __future__ import unicode_literals
from django.db import models
from datetime import datetime

class ShowManager(models.Manager):
    def basic_validations(self, postData):
        errors = {}

        if len(postData['title']) < 2:
            errors['title'] = "Title should be at least 2 characters"
        if len(postData['network']) < 3:
            errors['network'] = "Network should be at least 2 characters"
        if len(postData['description']) < 10 and len(postData['description']) > 0:
            errors['description'] = "Description should be more than 10 characters"
        strp_date = datetime.strptime(postData['release_date'], '%Y-%m-%d')
        if strp_date > datetime.now():
            errors['release_date'] = "Release date cannot be in the future"
        return errors
        
    def title_validations(self, postData):
        errors = {}

        show_title = postData['title']
        current_title = Show.objects.filter(title=show_title)
        if len(current_title) !=0:
            errors['title'] = "Show already exists"
        return errors
        



class Show(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    network = models.CharField(max_length=255)
    release_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ShowManager()
  

    def __repr__(self):
        return f"title: {self.title} description: {self.description} network: {self.network} "