from django.apps import AppConfig


class FavbooksappConfig(AppConfig):
    name = 'favbooksapp'
